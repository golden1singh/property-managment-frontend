import { useState } from 'react'
import { useTranslation } from 'react-i18next'
import {
  HomeIcon,
  UserGroupIcon,
  CurrencyRupeeIcon,
  LightBulbIcon,
  BellIcon,
  ExclamationCircleIcon,
  ArrowUpIcon,
  ArrowDownIcon
} from '@heroicons/react/24/outline'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
} from 'chart.js'
import { Bar, Doughnut } from 'react-chartjs-2'
import ServiceCard from '../../components/common/ServiceCard'

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
)

const Dashboard = () => {
  const { t } = useTranslation()
  
  // Sample data
  const stats = [
    {
      id: 1,
      name: t('totalRooms'),
      value: '24',
      icon: HomeIcon,
      change: '+2',
      changeType: 'increase'
    },
    {
      id: 2,
      name: t('occupiedRooms'),
      value: '18',
      icon: UserGroupIcon,
      change: '+3',
      changeType: 'increase'
    },
    {
      id: 3,
      name: t('pendingRent'),
      value: '₹45,000',
      icon: CurrencyRupeeIcon,
      change: '-12%',
      changeType: 'decrease'
    },
    {
      id: 4,
      name: t('pendingUtilities'),
      value: '₹12,000',
      icon: LightBulbIcon,
      change: '+18%',
      changeType: 'increase'
    }
  ]

  const recentActivities = [
    {
      id: 1,
      type: 'payment',
      description: t('rentReceived', { room: '101' }),
      amount: '₹8,000',
      timestamp: '2 hours ago'
    },
    {
      id: 2,
      type: 'tenant',
      description: t('newTenant', { room: '204' }),
      timestamp: '5 hours ago'
    },
    {
      id: 3,
      type: 'utility',
      description: t('utilityPaid', { room: '103' }),
      amount: '₹1,200',
      timestamp: '1 day ago'
    }
  ]

  const alerts = [
    {
      id: 1,
      type: 'rent',
      message: 'Room 103 rent is overdue by 5 days',
      severity: 'high'
    },
    // Add more alerts
  ]

  // Chart data
  const rentCollectionData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    datasets: [
      {
        label: t('rentCollection'),
        data: [65000, 72000, 68000, 70000, 75000, 80000],
        backgroundColor: 'rgba(37, 99, 235, 0.5)',
        borderColor: 'rgb(37, 99, 235)',
        borderWidth: 1
      }
    ]
  }

  const occupancyData = {
    labels: [t('occupied'), t('vacant')],
    datasets: [
      {
        data: [18, 6],
        backgroundColor: [
          'rgba(34, 197, 94, 0.8)',
          'rgba(239, 68, 68, 0.8)'
        ],
        borderColor: [
          'rgb(34, 197, 94)',
          'rgb(239, 68, 68)'
        ],
        borderWidth: 1
      }
    ]
  }

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: t('monthlyRentCollection')
      }
    }
  }

  const doughnutOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'bottom',
      },
      title: {
        display: true,
        text: t('roomOccupancy')
      }
    }
  }

  const services = [
    {
      icon: HomeIcon,
      title: 'services.roomManagement',
      description: 'services.roomManagementDesc',
      color: 'bg-blue-500',
    },
    {
      icon: UserGroupIcon,
      title: 'services.tenantTracking',
      description: 'services.tenantTrackingDesc',
      color: 'bg-green-500',
    },
    {
      icon: CurrencyRupeeIcon,
      title: 'services.paymentHandling',
      description: 'services.paymentHandlingDesc',
      color: 'bg-purple-500',
    },
    {
      icon: HomeIcon,
      title: 'services.maintenance',
      description: 'services.maintenanceDesc',
      color: 'bg-orange-500',
    },
  ]

  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-2xl font-semibold text-gray-900">{t('dashboard')}</h1>

        {/* Stats Grid */}
        <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat) => (
            <div
              key={stat.id}
              className="bg-white overflow-hidden shadow rounded-lg hover:shadow-md transition-shadow duration-300"
            >
              <div className="p-5">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="p-3 bg-primary-100 rounded-full">
                      <stat.icon className="h-6 w-6 text-primary-600" />
                    </div>
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">
                        {stat.name}
                      </dt>
                      <dd className="flex items-baseline">
                        <div className="text-2xl font-semibold text-gray-900">
                          {stat.value}
                        </div>
                        <div className={`ml-2 flex items-baseline text-sm font-semibold ${
                          stat.changeType === 'increase' ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {stat.changeType === 'increase' ? (
                            <ArrowUpIcon className="h-4 w-4" />
                          ) : (
                            <ArrowDownIcon className="h-4 w-4" />
                          )}
                          {stat.change}
                        </div>
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-8 grid grid-cols-1 gap-8 lg:grid-cols-2">
          {/* Charts */}
          <div className="bg-white rounded-lg shadow p-6">
            <Bar data={rentCollectionData} options={chartOptions} />
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <Doughnut data={occupancyData} options={doughnutOptions} />
          </div>
        </div>

        <div className="mt-8 grid grid-cols-1 gap-8 lg:grid-cols-2">
          {/* Recent Activities */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
              <BellIcon className="h-5 w-5 text-primary-600 mr-2" />
              {t('recentActivities')}
            </h2>
            <div className="flow-root">
              <ul className="-mb-8">
                {recentActivities.map((activity, activityIdx) => (
                  <li key={activity.id}>
                    <div className="relative pb-8">
                      {activityIdx !== recentActivities.length - 1 ? (
                        <span
                          className="absolute top-4 left-4 -ml-px h-full w-0.5 bg-gray-200"
                          aria-hidden="true"
                        />
                      ) : null}
                      <div className="relative flex space-x-3">
                        <div>
                          <span className={`h-8 w-8 rounded-full flex items-center justify-center ring-8 ring-white ${
                            activity.type === 'payment' ? 'bg-green-500' :
                            activity.type === 'tenant' ? 'bg-blue-500' : 'bg-yellow-500'
                          }`}>
                            <BellIcon className="h-5 w-5 text-white" />
                          </span>
                        </div>
                        <div className="flex min-w-0 flex-1 justify-between space-x-4 pt-1.5">
                          <div>
                            <p className="text-sm text-gray-500">
                              {activity.description}
                              {activity.amount && (
                                <span className="font-medium text-gray-900 ml-2">
                                  {activity.amount}
                                </span>
                              )}
                            </p>
                          </div>
                          <div className="text-right text-sm whitespace-nowrap text-gray-500">
                            <time>{activity.timestamp}</time>
                          </div>
                        </div>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-medium text-gray-900 mb-4">
              {t('quickActions')}
            </h2>
            <div className="grid grid-cols-2 gap-4">
              <button className="p-4 text-left rounded-lg border-2 border-gray-200 hover:border-primary-500 hover:bg-primary-50 transition-colors group">
                <UserGroupIcon className="h-6 w-6 text-gray-400 group-hover:text-primary-600 mb-2" />
                <h3 className="font-medium text-gray-900">{t('addTenant')}</h3>
                <p className="text-sm text-gray-500">{t('addTenantDesc')}</p>
              </button>
              <button className="p-4 text-left rounded-lg border-2 border-gray-200 hover:border-primary-500 hover:bg-primary-50 transition-colors group">
                <CurrencyRupeeIcon className="h-6 w-6 text-gray-400 group-hover:text-primary-600 mb-2" />
                <h3 className="font-medium text-gray-900">{t('recordPayment')}</h3>
                <p className="text-sm text-gray-500">{t('recordPaymentDesc')}</p>
              </button>
            </div>
          </div>
        </div>

        {/* Alerts */}
        <div className="mt-8">
          <h2 className="text-lg font-medium text-gray-900 mb-4">
            {t('alerts')}
          </h2>
          <div className="bg-white shadow rounded-lg divide-y divide-gray-200">
            {alerts.map((alert) => (
              <div
                key={alert.id}
                className="p-4 flex items-center justify-between"
              >
                <div className="flex items-center">
                  <ExclamationCircleIcon
                    className={`h-5 w-5 ${
                      alert.severity === 'high' ? 'text-red-500' : 'text-yellow-500'
                    }`}
                  />
                  <p className="ml-3 text-sm text-gray-500">{alert.message}</p>
                </div>
                <button
                  type="button"
                  className="ml-6 bg-white rounded-md text-sm font-medium text-primary-600 hover:text-primary-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                >
                  {t('view')}
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Services Section */}
        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-6">
          {t('services.title')}
        </h2>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {services.map((service, index) => (
            <ServiceCard
              key={index}
              icon={service.icon}
              title={service.title}
              description={service.description}
              color={service.color}
            />
          ))}
        </div>
      </div>
    </div>
  )
}

export default Dashboard