import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import {
  PlusIcon,
  HomeModernIcon,
  FunnelIcon,
  MagnifyingGlassIcon
} from '@heroicons/react/24/outline'

const RoomList = () => {
  const { t } = useTranslation()
  const navigate = useNavigate()
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedPlot, setSelectedPlot] = useState('all')
  const [filterStatus, setFilterStatus] = useState('all')

  // Sample data - replace with your API data
  const plots = [
    {
      id: '129',
      number: '129',
      rooms: [
        { id: 1, number: '101', status: 'occupied', tenant: 'John Doe', rent: 15000 },
        { id: 2, number: '102', status: 'available', rent: 14000 },
        // ... more rooms
      ]
    },
    {
      id: '239',
      number: '239',
      rooms: [
        { id: 3, number: '201', status: 'maintenance', rent: 16000 },
        { id: 4, number: '202', status: 'occupied', tenant: 'Jane Smith', rent: 15500 },
        // ... more rooms
      ]
    }
  ]

  const filteredPlots = plots.map(plot => ({
    ...plot,
    rooms: plot.rooms.filter(room => {
      const matchesSearch = 
        room.number.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (room.tenant?.toLowerCase() || '').includes(searchTerm.toLowerCase())
      const matchesStatus = filterStatus === 'all' || room.status === filterStatus
      return matchesSearch && matchesStatus
    })
  })).filter(plot => 
    selectedPlot === 'all' || plot.number === selectedPlot
  )

  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <h1 className="text-2xl font-semibold text-gray-900">{t('rooms')}</h1>
          
          <button
            type="button"
            onClick={() => navigate('/rooms/add')}
            className="mt-4 sm:mt-0 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
          >
            <PlusIcon className="-ml-1 mr-2 h-5 w-5" />
            {t('addRoom')}
          </button>
        </div>

        {/* Filters */}
        <div className="mt-6 bg-white shadow rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-4">
              <div>
                <label htmlFor="search" className="sr-only">{t('search')}</label>
                <div className="relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <MagnifyingGlassIcon className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    name="search"
                    id="search"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="block w-full pl-10 sm:text-sm border-gray-300 rounded-md focus:ring-primary-500 focus:border-primary-500"
                    placeholder={t('searchRooms')}
                  />
                </div>
              </div>

              <div>
                <select
                  value={selectedPlot}
                  onChange={(e) => setSelectedPlot(e.target.value)}
                  className="block w-full sm:text-sm border-gray-300 rounded-md focus:ring-primary-500 focus:border-primary-500"
                >
                  <option value="all">{t('allPlots')}</option>
                  {plots.map(plot => (
                    <option key={plot.id} value={plot.number}>
                      {t('plotNumber', { number: plot.number })}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="block w-full sm:text-sm border-gray-300 rounded-md focus:ring-primary-500 focus:border-primary-500"
                >
                  <option value="all">{t('allStatus')}</option>
                  <option value="available">{t('roomStatus.available')}</option>
                  <option value="occupied">{t('roomStatus.occupied')}</option>
                  <option value="maintenance">{t('roomStatus.maintenance')}</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        {/* Plots and Rooms */}
        <div className="mt-8 space-y-8">
          {filteredPlots.map(plot => (
            <div key={plot.id} className="bg-white shadow overflow-hidden sm:rounded-lg">
              <div className="px-4 py-5 sm:px-6 flex justify-between items-center">
                <h3 className="text-lg leading-6 font-medium text-gray-900">
                  {t('plotWithRooms', { 
                    number: plot.number,
                    available: plot.rooms.filter(r => r.status === 'available').length,
                    total: plot.rooms.length
                  })}
                </h3>
              </div>
              
              <div className="border-t border-gray-200">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 p-4">
                  {plot.rooms.map(room => (
                    <div
                      key={room.id}
                      className="relative rounded-lg border border-gray-300 bg-white px-6 py-5 shadow-sm hover:border-gray-400 focus-within:ring-2 focus-within:ring-primary-500 focus-within:ring-offset-2"
                    >
                      <div className="flex justify-between">
                        <div>
                          <h4 className="text-lg font-semibold">{t('roomNumber', { number: room.number })}</h4>
                          <p className="mt-1 text-sm text-gray-500">
                            {room.tenant ? room.tenant : t('vacant')}
                          </p>
                        </div>
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                          ${room.status === 'available' ? 'bg-green-100 text-green-800' :
                            room.status === 'occupied' ? 'bg-blue-100 text-blue-800' :
                            'bg-yellow-100 text-yellow-800'}`}>
                          {t(`roomStatus.${room.status}`)}
                        </span>
                      </div>
                      <div className="mt-2">
                        <p className="text-sm font-medium text-gray-900">
                          ₹{room.rent.toLocaleString()}/month
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export default RoomList 