import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  PhotoIcon,
  XMarkIcon,
  PlusIcon
} from '@heroicons/react/24/outline';

const AddRoom = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [images, setImages] = useState([]);
  const [formData, setFormData] = useState({
    plotNumber: '',
    roomNumber: '',
    floor: '',
    type: 'single', // single, double, suite
    rent: '',
    securityDeposit: '',
    area: '',
    furnishingStatus: 'unfurnished', // unfurnished, semi-furnished, fully-furnished
    amenities: [],
    description: '',
    status: 'available' // available, occupied, maintenance
  });

  const amenitiesOptions = [
    'ac', 'wifi', 'bathroom', 'balcony', 'kitchen', 
    'tv', 'fridge', 'washing_machine', 'water_heater'
  ];

  // Sample plot data - replace with your API data
  const plots = [
    { id: '129', number: '129', totalRooms: 8, availableRooms: 3 },
    { id: '239', number: '239', totalRooms: 11, availableRooms: 5 },
    // Add more plots as needed
  ];

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleAmenityToggle = (amenity) => {
    setFormData(prev => ({
      ...prev,
      amenities: prev.amenities.includes(amenity)
        ? prev.amenities.filter(a => a !== amenity)
        : [...prev.amenities, amenity]
    }));
  };

  const handleImageUpload = (e) => {
    const files = Array.from(e.target.files);
    const newImages = files.map(file => ({
      id: Math.random().toString(36).substr(2, 9),
      file,
      preview: URL.createObjectURL(file)
    }));
    setImages(prev => [...prev, ...newImages]);
  };

  const removeImage = (id) => {
    setImages(prev => {
      const filtered = prev.filter(img => img.id !== id);
      // Revoke the URL to prevent memory leaks
      const removed = prev.find(img => img.id === id);
      if (removed) {
        URL.revokeObjectURL(removed.preview);
      }
      return filtered;
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      // API call to save room data
      // const formDataToSend = new FormData();
      // Object.keys(formData).forEach(key => {
      //   formDataToSend.append(key, formData[key]);
      // });
      // images.forEach(img => {
      //   formDataToSend.append('images', img.file);
      // });
      // await addRoom(formDataToSend);
      
      navigate('/rooms');
    } catch (error) {
      console.error('Error adding room:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-2xl font-semibold text-gray-900">{t('addRoomTitle')}</h1>

        <form onSubmit={handleSubmit} className="mt-6 space-y-8">
          {/* Plot and Basic Information */}
          <div className="bg-white shadow sm:rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg font-medium leading-6 text-gray-900">
                {t('roomBasicInfo')}
              </h3>
              <div className="mt-6 grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
                {/* Plot Selection */}
                <div className="sm:col-span-2">
                  <label htmlFor="plotNumber" className="block text-sm font-medium text-gray-700">
                    {t('plotNumber')}
                  </label>
                  <select
                    name="plotNumber"
                    id="plotNumber"
                    required
                    value={formData.plotNumber}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  >
                    <option value="">{t('selectPlot')}</option>
                    {plots.map(plot => (
                      <option key={plot.id} value={plot.number}>
                        {t('plotWithRooms', { 
                          number: plot.number, 
                          available: plot.availableRooms, 
                          total: plot.totalRooms 
                        })}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <label htmlFor="roomNumber" className="block text-sm font-medium text-gray-700">
                    {t('roomNumber')}
                  </label>
                  <input
                    type="text"
                    name="roomNumber"
                    id="roomNumber"
                    required
                    value={formData.roomNumber}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label htmlFor="floor" className="block text-sm font-medium text-gray-700">
                    {t('floor')}
                  </label>
                  <input
                    type="number"
                    name="floor"
                    id="floor"
                    required
                    value={formData.floor}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label htmlFor="type" className="block text-sm font-medium text-gray-700">
                    {t('roomType')}
                  </label>
                  <select
                    name="type"
                    id="type"
                    required
                    value={formData.type}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  >
                    <option value="single">{t('roomTypes.single')}</option>
                    <option value="double">{t('roomTypes.double')}</option>
                    <option value="suite">{t('roomTypes.suite')}</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          {/* Pricing */}
          <div className="bg-white shadow sm:rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg font-medium leading-6 text-gray-900">
                {t('roomPricing')}
              </h3>
              <div className="mt-6 grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
                <div className="sm:col-span-3">
                  <label htmlFor="rent" className="block text-sm font-medium text-gray-700">
                    {t('monthlyRent')}
                  </label>
                  <div className="mt-1 relative rounded-md shadow-sm">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <span className="text-gray-500 sm:text-sm">₹</span>
                    </div>
                    <input
                      type="number"
                      name="rent"
                      id="rent"
                      required
                      value={formData.rent}
                      onChange={handleInputChange}
                      className="mt-1 block w-full pl-7 rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                    />
                  </div>
                </div>

                <div className="sm:col-span-3">
                  <label htmlFor="securityDeposit" className="block text-sm font-medium text-gray-700">
                    {t('securityDeposit')}
                  </label>
                  <div className="mt-1 relative rounded-md shadow-sm">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <span className="text-gray-500 sm:text-sm">₹</span>
                    </div>
                    <input
                      type="number"
                      name="securityDeposit"
                      id="securityDeposit"
                      required
                      value={formData.securityDeposit}
                      onChange={handleInputChange}
                      className="mt-1 block w-full pl-7 rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Room Details */}
          <div className="bg-white shadow sm:rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg font-medium leading-6 text-gray-900">
                {t('roomDetails')}
              </h3>
              <div className="mt-6 grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
                <div className="sm:col-span-2">
                  <label htmlFor="area" className="block text-sm font-medium text-gray-700">
                    {t('area')} (sq ft)
                  </label>
                  <input
                    type="number"
                    name="area"
                    id="area"
                    required
                    value={formData.area}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label htmlFor="furnishingStatus" className="block text-sm font-medium text-gray-700">
                    {t('furnishingStatus')}
                  </label>
                  <select
                    name="furnishingStatus"
                    id="furnishingStatus"
                    required
                    value={formData.furnishingStatus}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  >
                    <option value="unfurnished">{t('furnishing.unfurnished')}</option>
                    <option value="semi-furnished">{t('furnishing.semiFurnished')}</option>
                    <option value="fully-furnished">{t('furnishing.fullyFurnished')}</option>
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <label htmlFor="status" className="block text-sm font-medium text-gray-700">
                    {t('status')}
                  </label>
                  <select
                    name="status"
                    id="status"
                    required
                    value={formData.status}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  >
                    <option value="available">{t('roomStatus.available')}</option>
                    <option value="occupied">{t('roomStatus.occupied')}</option>
                    <option value="maintenance">{t('roomStatus.maintenance')}</option>
                  </select>
                </div>
              </div>

              {/* Amenities */}
              <div className="mt-6">
                <label className="text-sm font-medium text-gray-700">
                  {t('amenities')}
                </label>
                <div className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4">
                  {amenitiesOptions.map(amenity => (
                    <div key={amenity} className="relative flex items-start">
                      <div className="flex h-5 items-center">
                        <input
                          type="checkbox"
                          checked={formData.amenities.includes(amenity)}
                          onChange={() => handleAmenityToggle(amenity)}
                          className="h-4 w-4 rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                        />
                      </div>
                      <div className="ml-3 text-sm">
                        <label className="font-medium text-gray-700">
                          {t(`amenities.${amenity}`)}
                        </label>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Description */}
              <div className="mt-6">
                <label htmlFor="description" className="block text-sm font-medium text-gray-700">
                  {t('description')}
                </label>
                <textarea
                  name="description"
                  id="description"
                  rows={4}
                  value={formData.description}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                />
              </div>
            </div>
          </div>

          {/* Room Images */}
          <div className="bg-white shadow sm:rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg font-medium leading-6 text-gray-900">
                {t('roomImages')}
              </h3>
              <div className="mt-6">
                <div className="flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
                  <div className="space-y-1 text-center">
                    <PhotoIcon className="mx-auto h-12 w-12 text-gray-400" />
                    <div className="flex text-sm text-gray-600">
                      <label
                        htmlFor="image-upload"
                        className="relative cursor-pointer rounded-md bg-white font-medium text-primary-600 focus-within:outline-none focus-within:ring-2 focus-within:ring-primary-500 focus-within:ring-offset-2 hover:text-primary-500"
                      >
                        <span>{t('uploadImages')}</span>
                        <input
                          id="image-upload"
                          type="file"
                          multiple
                          accept="image/*"
                          onChange={handleImageUpload}
                          className="sr-only"
                        />
                      </label>
                      <p className="pl-1">{t('dragAndDrop')}</p>
                    </div>
                    <p className="text-xs text-gray-500">{t('allowedImageTypes')}</p>
                  </div>
                </div>

                {/* Image Preview */}
                {images.length > 0 && (
                  <div className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4">
                    {images.map(image => (
                      <div key={image.id} className="relative">
                        <img
                          src={image.preview}
                          alt=""
                          className="h-24 w-full object-cover rounded-lg"
                        />
                        <button
                          type="button"
                          onClick={() => removeImage(image.id)}
                          className="absolute -top-2 -right-2 inline-flex items-center p-1 border border-transparent rounded-full shadow-sm text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                        >
                          <XMarkIcon className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex justify-end space-x-4">
            <button
              type="button"
              onClick={() => navigate('/rooms')}
              className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
            >
              {t('cancel')}
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 disabled:bg-gray-400 disabled:cursor-not-allowed"
            >
              {loading ? t('saving') : t('saveRoom')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddRoom; 