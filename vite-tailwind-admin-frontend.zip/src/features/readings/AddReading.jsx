import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import {
  CameraIcon,
  ArrowLeftIcon
} from '@heroicons/react/24/outline'

const AddReading = () => {
  const { t } = useTranslation()
  const navigate = useNavigate()
  const [loading, setLoading] = useState(false)
  const [readingImage, setReadingImage] = useState(null)
  const [preview, setPreview] = useState(null)

  const [formData, setFormData] = useState({
    plotNumber: '',
    roomNumber: '',
    readingType: 'electricity', // electricity, water, gas
    readingDate: new Date().toISOString().split('T')[0],
    previousReading: '',
    currentReading: '',
    ratePerUnit: '',
    additionalCharges: '',
    notes: ''
  })

  // Sample data - replace with API data
  const plots = [
    { id: '129', number: '129', rooms: ['101', '102', '103'] },
    { id: '239', number: '239', rooms: ['201', '202', '203'] }
  ]

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
  }

  const handleImageChange = (e) => {
    const file = e.target.files[0]
    if (file) {
      setReadingImage(file)
      setPreview(URL.createObjectURL(file))
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    try {
      // API call to save reading
      console.log('Saving reading:', formData)
      navigate('/readings')
    } catch (error) {
      console.error('Error saving reading:', error)
    } finally {
      setLoading(false)
    }
  }

  const calculateAmount = () => {
    const units = formData.currentReading - formData.previousReading
    const amount = units * formData.ratePerUnit
    const total = amount + Number(formData.additionalCharges || 0)
    return total.toFixed(2)
  }

  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center mb-6">
          <button
            onClick={() => navigate('/readings')}
            className="mr-4 text-gray-600 hover:text-gray-900"
          >
            <ArrowLeftIcon className="h-6 w-6" />
          </button>
          <h1 className="text-2xl font-semibold text-gray-900">{t('readings.addReading')}</h1>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Location Details */}
          <div className="bg-white shadow sm:rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg font-medium text-gray-900">
                {t('readings.locationDetails')}
              </h3>
              <div className="mt-6 grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
                <div className="sm:col-span-3">
                  <label htmlFor="plotNumber" className="block text-sm font-medium text-gray-700">
                    {t('readings.plotNumber')}
                  </label>
                  <select
                    id="plotNumber"
                    name="plotNumber"
                    required
                    value={formData.plotNumber}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  >
                    <option value="">{t('readings.selectPlot')}</option>
                    {plots.map(plot => (
                      <option key={plot.id} value={plot.number}>
                        {t('readings.plotWithNumber', { number: plot.number })}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="sm:col-span-3">
                  <label htmlFor="roomNumber" className="block text-sm font-medium text-gray-700">
                    {t('readings.roomNumber')}
                  </label>
                  <select
                    id="roomNumber"
                    name="roomNumber"
                    required
                    value={formData.roomNumber}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  >
                    <option value="">{t('readings.selectRoom')}</option>
                    {formData.plotNumber && plots
                      .find(p => p.number === formData.plotNumber)?.rooms
                      .map(room => (
                        <option key={room} value={room}>{room}</option>
                      ))
                    }
                  </select>
                </div>
              </div>
            </div>
          </div>

          {/* Reading Details */}
          <div className="bg-white shadow sm:rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg font-medium text-gray-900">
                {t('readings.readingDetails')}
              </h3>
              <div className="mt-6 grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
                <div className="sm:col-span-3">
                  <label htmlFor="readingType" className="block text-sm font-medium text-gray-700">
                    {t('readings.readingType')}
                  </label>
                  <select
                    id="readingType"
                    name="readingType"
                    required
                    value={formData.readingType}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  >
                    <option value="electricity">{t('readings.types.electricity')}</option>
                    <option value="water">{t('readings.types.water')}</option>
                    <option value="gas">{t('readings.types.gas')}</option>
                  </select>
                </div>

                <div className="sm:col-span-3">
                  <label htmlFor="readingDate" className="block text-sm font-medium text-gray-700">
                    {t('readings.readingDate')}
                  </label>
                  <input
                    type="date"
                    id="readingDate"
                    name="readingDate"
                    required
                    value={formData.readingDate}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  />
                </div>

                <div className="sm:col-span-3">
                  <label htmlFor="previousReading" className="block text-sm font-medium text-gray-700">
                    {t('readings.previousReading')}
                  </label>
                  <input
                    type="number"
                    id="previousReading"
                    name="previousReading"
                    required
                    value={formData.previousReading}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  />
                </div>

                <div className="sm:col-span-3">
                  <label htmlFor="currentReading" className="block text-sm font-medium text-gray-700">
                    {t('readings.currentReading')}
                  </label>
                  <input
                    type="number"
                    id="currentReading"
                    name="currentReading"
                    required
                    value={formData.currentReading}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  />
                </div>

                <div className="sm:col-span-3">
                  <label htmlFor="ratePerUnit" className="block text-sm font-medium text-gray-700">
                    {t('readings.ratePerUnit')}
                  </label>
                  <div className="mt-1 relative rounded-md shadow-sm">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <span className="text-gray-500 sm:text-sm">₹</span>
                    </div>
                    <input
                      type="number"
                      id="ratePerUnit"
                      name="ratePerUnit"
                      required
                      value={formData.ratePerUnit}
                      onChange={handleInputChange}
                      className="pl-7 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                    />
                  </div>
                </div>

                <div className="sm:col-span-3">
                  <label htmlFor="additionalCharges" className="block text-sm font-medium text-gray-700">
                    {t('readings.additionalCharges')}
                  </label>
                  <div className="mt-1 relative rounded-md shadow-sm">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <span className="text-gray-500 sm:text-sm">₹</span>
                    </div>
                    <input
                      type="number"
                      id="additionalCharges"
                      name="additionalCharges"
                      value={formData.additionalCharges}
                      onChange={handleInputChange}
                      className="pl-7 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                    />
                  </div>
                </div>
              </div>

              {/* Reading Image */}
              <div className="mt-6">
                <label className="block text-sm font-medium text-gray-700">
                  {t('readings.meterImage')}
                </label>
                <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
                  <div className="space-y-1 text-center">
                    {preview ? (
                      <div>
                        <img src={preview} alt="Meter reading" className="mx-auto h-48 w-auto" />
                        <button
                          type="button"
                          onClick={() => {
                            setReadingImage(null)
                            setPreview(null)
                          }}
                          className="mt-2 text-sm text-red-600 hover:text-red-500"
                        >
                          {t('readings.removeImage')}
                        </button>
                      </div>
                    ) : (
                      <>
                        <CameraIcon className="mx-auto h-12 w-12 text-gray-400" />
                        <div className="flex text-sm text-gray-600">
                          <label htmlFor="reading-image" className="relative cursor-pointer rounded-md bg-white font-medium text-primary-600 hover:text-primary-500">
                            <span>{t('readings.uploadImage')}</span>
                            <input
                              id="reading-image"
                              name="reading-image"
                              type="file"
                              accept="image/*"
                              className="sr-only"
                              onChange={handleImageChange}
                            />
                          </label>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </div>

              {/* Notes */}
              <div className="mt-6">
                <label htmlFor="notes" className="block text-sm font-medium text-gray-700">
                  {t('readings.notes')}
                </label>
                <textarea
                  id="notes"
                  name="notes"
                  rows={3}
                  value={formData.notes}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                />
              </div>

              {/* Total Amount */}
              {formData.currentReading && formData.previousReading && formData.ratePerUnit && (
                <div className="mt-6 p-4 bg-gray-50 rounded-md">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-700">{t('readings.totalAmount')}</span>
                    <span className="text-lg font-semibold text-gray-900">₹{calculateAmount()}</span>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex justify-end space-x-4">
            <button
              type="button"
              onClick={() => navigate('/readings')}
              className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
            >
              {t('common.cancel')}
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 disabled:bg-gray-400 disabled:cursor-not-allowed"
            >
              {loading ? t('common.saving') : t('readings.saveReading')}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default AddReading 