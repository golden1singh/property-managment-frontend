import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import {
  PlusIcon,
  FunnelIcon,
  MagnifyingGlassIcon,
  BeakerIcon
} from '@heroicons/react/24/outline'

const ReadingList = () => {
  const { t } = useTranslation()
  const navigate = useNavigate()
  const [searchTerm, setSearchTerm] = useState('')
  const [filterType, setFilterType] = useState('all')
  const [filterMonth, setFilterMonth] = useState('all')

  // Sample data - replace with API call
  const readings = [
    {
      id: 1,
      plotNumber: '129',
      roomNumber: '101',
      type: 'electricity',
      date: '2024-03-15',
      previousReading: 1000,
      currentReading: 1200,
      unitsConsumed: 200,
      ratePerUnit: 8,
      additionalCharges: 50,
      totalAmount: 1650,
      status: 'pending'
    },
    // Add more sample readings
  ]

  const filteredReadings = readings.filter(reading => {
    const matchesSearch = 
      reading.plotNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      reading.roomNumber.toLowerCase().includes(searchTerm.toLowerCase())
    
    const matchesType = filterType === 'all' || reading.type === filterType
    
    const matchesMonth = filterMonth === 'all' || 
      new Date(reading.date).getMonth() === parseInt(filterMonth)

    return matchesSearch && matchesType && matchesMonth
  })

  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-semibold text-gray-900">
            {t('readings.title')}
          </h1>
          <button
            onClick={() => navigate('/readings/add')}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
          >
            <PlusIcon className="-ml-1 mr-2 h-5 w-5" />
            {t('readings.addReading')}
          </button>
        </div>

        {/* Filters and Search */}
        <div className="mt-6 flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <div className="relative rounded-md shadow-sm">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <MagnifyingGlassIcon className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder={t('readings.searchPlaceholder')}
                className="block w-full pl-10 sm:text-sm border-gray-300 rounded-md focus:ring-primary-500 focus:border-primary-500"
              />
            </div>
          </div>

          <div className="flex gap-4">
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="block w-full sm:text-sm border-gray-300 rounded-md focus:ring-primary-500 focus:border-primary-500"
            >
              <option value="all">{t('readings.allTypes')}</option>
              <option value="electricity">{t('readings.types.electricity')}</option>
              <option value="water">{t('readings.types.water')}</option>
              <option value="gas">{t('readings.types.gas')}</option>
            </select>

            <select
              value={filterMonth}
              onChange={(e) => setFilterMonth(e.target.value)}
              className="block w-full sm:text-sm border-gray-300 rounded-md focus:ring-primary-500 focus:border-primary-500"
            >
              <option value="all">{t('readings.allMonths')}</option>
              {Array.from({ length: 12 }, (_, i) => (
                <option key={i} value={i}>
                  {new Date(2024, i).toLocaleString('default', { month: 'long' })}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Readings List */}
        <div className="mt-6 bg-white shadow overflow-hidden sm:rounded-md">
          <ul className="divide-y divide-gray-200">
            {filteredReadings.map((reading) => (
              <li key={reading.id}>
                <div className="px-4 py-4 sm:px-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <BeakerIcon className="h-6 w-6 text-gray-400" />
                      <div className="ml-4">
                        <p className="text-sm font-medium text-gray-900">
                          {t('readings.plotRoom', { 
                            plot: reading.plotNumber, 
                            room: reading.roomNumber 
                          })}
                        </p>
                        <p className="text-sm text-gray-500">
                          {t(`readings.types.${reading.type}`)} - {new Date(reading.date).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="text-sm font-medium text-gray-900">
                          {reading.unitsConsumed} {t('readings.units')}
                        </p>
                        <p className="text-sm text-gray-500">
                          ₹{reading.totalAmount}
                        </p>
                      </div>
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                        ${reading.status === 'paid' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
                        {t(`readings.status.${reading.status}`)}
                      </span>
                    </div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  )
}

export default ReadingList 