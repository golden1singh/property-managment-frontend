import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import {
  PhotoIcon,
  XMarkIcon,
  ArrowLeftIcon
} from '@heroicons/react/24/outline'

const EditTenant = () => {
  const { id } = useParams()
  const { t } = useTranslation()
  const navigate = useNavigate()
  const [loading, setLoading] = useState(false)
  const [preview, setPreview] = useState(null)

  // Initial form state with tenant data
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    emergencyContact: '',
    emergencyPhone: '',
    occupation: '',
    employer: '',
    monthlyIncome: '',
    joiningDate: '',
    currentAddress: '',
    permanentAddress: '',
    photo: null,
    documents: [],
    plotNumber: '',
    roomNumber: '',
    rent: '',
    deposit: '',
    startDate: '',
    endDate: ''
  })

  // Fetch tenant data when component mounts
  useEffect(() => {
    const fetchTenantData = async () => {
      try {
        // Replace with actual API call
        const tenant = {
          id,
          firstName: 'John',
          lastName: 'Doe',
          email: 'john.doe@example.com',
          phone: '+91 9876543210',
          emergencyContact: 'Jane Doe',
          emergencyPhone: '+91 9876543211',
          occupation: 'Software Engineer',
          employer: 'Tech Corp',
          monthlyIncome: 75000,
          joiningDate: '2024-01-15',
          address: {
            current: '123 Main St, City, State',
            permanent: '456 Home St, Hometown, State'
          },
          photo: null,
          documents: [
            { id: 1, type: 'aadhar', number: '1234-5678-9012', file: '/path/to/aadhar.pdf' },
            { id: 2, type: 'pan', number: 'ABCDE1234F', file: '/path/to/pan.pdf' }
          ],
          room: {
            plotNumber: '129',
            roomNumber: '101',
            rent: 15000,
            deposit: 30000,
            startDate: '2024-01-15',
            endDate: '2025-01-14'
          }
        }

        setFormData({
          firstName: tenant.firstName,
          lastName: tenant.lastName,
          email: tenant.email,
          phone: tenant.phone,
          emergencyContact: tenant.emergencyContact,
          emergencyPhone: tenant.emergencyPhone,
          occupation: tenant.occupation,
          employer: tenant.employer,
          monthlyIncome: tenant.monthlyIncome,
          joiningDate: tenant.joiningDate,
          currentAddress: tenant.address.current,
          permanentAddress: tenant.address.permanent,
          photo: tenant.photo,
          documents: tenant.documents,
          plotNumber: tenant.room.plotNumber,
          roomNumber: tenant.room.roomNumber,
          rent: tenant.room.rent,
          deposit: tenant.room.deposit,
          startDate: tenant.room.startDate,
          endDate: tenant.room.endDate
        })

        if (tenant.photo) {
          setPreview(tenant.photo)
        }
      } catch (error) {
        console.error('Error fetching tenant data:', error)
      }
    }

    fetchTenantData()
  }, [id])

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
  }

  const handlePhotoChange = (e) => {
    const file = e.target.files[0]
    if (file) {
      setFormData(prev => ({
        ...prev,
        photo: file
      }))
      setPreview(URL.createObjectURL(file))
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    try {
      // API call to update tenant
      // await updateTenant(id, formData)
      navigate(`/tenants/${id}`)
    } catch (error) {
      console.error('Error updating tenant:', error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <button
              type="button"
              onClick={() => navigate(`/tenants/${id}`)}
              className="mr-4 text-gray-500 hover:text-gray-700"
            >
              <ArrowLeftIcon className="h-6 w-6" />
            </button>
            <h1 className="text-2xl font-semibold text-gray-900">
              {t('editTenant')}
            </h1>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="mt-6 space-y-8">
          {/* Personal Information */}
          <div className="bg-white shadow sm:rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg font-medium text-gray-900">
                {t('personalInformation')}
              </h3>
              <div className="mt-6 grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
                {/* Photo Upload */}
                <div className="sm:col-span-6">
                  <label className="block text-sm font-medium text-gray-700">
                    {t('photo')}
                  </label>
                  <div className="mt-1 flex items-center">
                    {preview ? (
                      <div className="relative">
                        <img
                          src={preview}
                          alt={t('tenantPhoto')}
                          className="h-32 w-32 rounded-full object-cover"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            setPreview(null)
                            setFormData(prev => ({ ...prev, photo: null }))
                          }}
                          className="absolute -top-2 -right-2 inline-flex items-center p-1 border border-transparent rounded-full shadow-sm text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                        >
                          <XMarkIcon className="h-4 w-4" />
                        </button>
                      </div>
                    ) : (
                      <div className="relative">
                        <div className="h-32 w-32 rounded-full overflow-hidden bg-gray-100">
                          <PhotoIcon className="h-full w-full text-gray-300" />
                        </div>
                        <button
                          type="button"
                          onClick={() => document.getElementById('photo-upload').click()}
                          className="absolute bottom-0 right-0 inline-flex items-center p-2 border border-transparent rounded-full shadow-sm text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                        >
                          <PhotoIcon className="h-5 w-5" />
                        </button>
                      </div>
                    )}
                    <input
                      type="file"
                      id="photo-upload"
                      accept="image/*"
                      onChange={handlePhotoChange}
                      className="hidden"
                    />
                  </div>
                </div>

                {/* Name Fields */}
                <div className="sm:col-span-3">
                  <label htmlFor="firstName" className="block text-sm font-medium text-gray-700">
                    {t('firstName')}
                  </label>
                  <input
                    type="text"
                    name="firstName"
                    id="firstName"
                    value={formData.firstName}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  />
                </div>

                <div className="sm:col-span-3">
                  <label htmlFor="lastName" className="block text-sm font-medium text-gray-700">
                    {t('lastName')}
                  </label>
                  <input
                    type="text"
                    name="lastName"
                    id="lastName"
                    value={formData.lastName}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  />
                </div>

                {/* Contact Information */}
                <div className="sm:col-span-3">
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                    {t('email')}
                  </label>
                  <input
                    type="email"
                    name="email"
                    id="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  />
                </div>

                <div className="sm:col-span-3">
                  <label htmlFor="phone" className="block text-sm font-medium text-gray-700">
                    {t('phone')}
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    id="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Employment Information */}
          <div className="bg-white shadow sm:rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg font-medium text-gray-900">
                {t('employmentInformation')}
              </h3>
              <div className="mt-6 grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
                <div className="sm:col-span-3">
                  <label htmlFor="occupation" className="block text-sm font-medium text-gray-700">
                    {t('occupation')}
                  </label>
                  <input
                    type="text"
                    name="occupation"
                    id="occupation"
                    value={formData.occupation}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  />
                </div>

                <div className="sm:col-span-3">
                  <label htmlFor="employer" className="block text-sm font-medium text-gray-700">
                    {t('employer')}
                  </label>
                  <input
                    type="text"
                    name="employer"
                    id="employer"
                    value={formData.employer}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  />
                </div>

                <div className="sm:col-span-3">
                  <label htmlFor="monthlyIncome" className="block text-sm font-medium text-gray-700">
                    {t('monthlyIncome')}
                  </label>
                  <input
                    type="number"
                    name="monthlyIncome"
                    id="monthlyIncome"
                    value={formData.monthlyIncome}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Room Information */}
          <div className="bg-white shadow sm:rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg font-medium text-gray-900">
                {t('roomInformation')}
              </h3>
              <div className="mt-6 grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
                <div className="sm:col-span-2">
                  <label htmlFor="plotNumber" className="block text-sm font-medium text-gray-700">
                    {t('plotNumber')}
                  </label>
                  <input
                    type="text"
                    name="plotNumber"
                    id="plotNumber"
                    value={formData.plotNumber}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label htmlFor="roomNumber" className="block text-sm font-medium text-gray-700">
                    {t('roomNumber')}
                  </label>
                  <input
                    type="text"
                    name="roomNumber"
                    id="roomNumber"
                    value={formData.roomNumber}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label htmlFor="rent" className="block text-sm font-medium text-gray-700">
                    {t('monthlyRent')}
                  </label>
                  <input
                    type="number"
                    name="rent"
                    id="rent"
                    value={formData.rent}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex justify-end space-x-4">
            <button
              type="button"
              onClick={() => navigate(`/tenants/${id}`)}
              className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
            >
              {t('cancel')}
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 disabled:bg-gray-400 disabled:cursor-not-allowed"
            >
              {loading ? t('saving') : t('saveTenant')}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default EditTenant 