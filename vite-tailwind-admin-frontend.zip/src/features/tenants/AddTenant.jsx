import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  PhotoIcon,
  DocumentIcon,
  XMarkIcon,
  ArrowUpTrayIcon,
  PlusIcon
} from '@heroicons/react/24/outline';

const AddTenant = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [preview, setPreview] = useState(null);
  const [documents, setDocuments] = useState([]);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    emergencyContact: '',
    emergencyPhone: '',
    occupation: '',
    employer: '',
    monthlyIncome: '',
    moveInDate: '',
    leaseLength: '12',
    roomNumber: '',
    rentAmount: '',
    depositAmount: '',
    idProof: '',
    photo: null,
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handlePhotoChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData(prev => ({
        ...prev,
        photo: file
      }));
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDocumentUpload = (e) => {
    const files = Array.from(e.target.files);
    const newDocuments = files.map(file => ({
      id: Math.random().toString(36).substr(2, 9),
      name: file.name,
      size: file.size,
      type: file.type,
      file: file
    }));
    setDocuments(prev => [...prev, ...newDocuments]);
  };

  const removeDocument = (id) => {
    setDocuments(prev => prev.filter(doc => doc.id !== id));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      // API call to save tenant data
      // const formDataToSend = new FormData();
      // Object.keys(formData).forEach(key => {
      //   formDataToSend.append(key, formData[key]);
      // });
      // documents.forEach(doc => {
      //   formDataToSend.append('documents', doc.file);
      // });
      // await addTenant(formDataToSend);
      
      navigate('/tenants');
    } catch (error) {
      console.error('Error adding tenant:', error);
    } finally {
      setLoading(false);
    }
  };

  const renderPhotoUpload = () => (
    <div className="sm:col-span-6">
      <label className="block text-sm font-medium text-gray-700">
        {t('photo')}
      </label>
      <div className="mt-1 flex items-center">
        {preview ? (
          <div className="relative">
            <img
              src={preview}
              alt={t('tenantPhoto')}
              className="h-32 w-32 rounded-full object-cover"
            />
            <button
              type="button"
              onClick={() => {
                setPreview(null)
                setFormData(prev => ({ ...prev, photo: null }))
              }}
              className="absolute -top-2 -right-2 inline-flex items-center p-1 border border-transparent rounded-full shadow-sm text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
            >
              <XMarkIcon className="h-4 w-4" />
            </button>
          </div>
        ) : (
          <div className="relative">
            <div className="h-32 w-32 rounded-full overflow-hidden bg-gray-100">
              <PhotoIcon className="h-full w-full text-gray-300" />
            </div>
            <button
              type="button"
              onClick={() => document.getElementById('photo-upload').click()}
              className="absolute bottom-0 right-0 inline-flex items-center p-2 border border-transparent rounded-full shadow-sm text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
            >
              <PlusIcon className="h-5 w-5" />
            </button>
          </div>
        )}
        <input
          type="file"
          id="photo-upload"
          accept="image/*"
          onChange={handlePhotoChange}
          className="hidden"
        />
      </div>
      <p className="mt-2 text-sm text-gray-500">
        {t('photoRequirements')}
      </p>
    </div>
  )

  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-2xl font-semibold text-gray-900">{t('addTenantTitle')}</h1>
        
        <form onSubmit={handleSubmit} className="mt-6 space-y-8">
          {/* Personal Information */}
          <div className="bg-white shadow sm:rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg font-medium leading-6 text-gray-900">
                {t('personalInformation')}
              </h3>
              <div className="mt-6 grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
                <div className="sm:col-span-3">
                  <label htmlFor="firstName" className="block text-sm font-medium text-gray-700">
                    {t('firstName')}
                  </label>
                  <input
                    type="text"
                    name="firstName"
                    id="firstName"
                    required
                    value={formData.firstName}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  />
                </div>

                <div className="sm:col-span-3">
                  <label htmlFor="lastName" className="block text-sm font-medium text-gray-700">
                    {t('lastName')}
                  </label>
                  <input
                    type="text"
                    name="lastName"
                    id="lastName"
                    required
                    value={formData.lastName}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  />
                </div>

                <div className="sm:col-span-3">
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                    {t('email')}
                  </label>
                  <input
                    type="email"
                    name="email"
                    id="email"
                    required
                    value={formData.email}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  />
                </div>

                <div className="sm:col-span-3">
                  <label htmlFor="phone" className="block text-sm font-medium text-gray-700">
                    {t('phone')}
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    id="phone"
                    required
                    value={formData.phone}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  />
                </div>

                {renderPhotoUpload()}
              </div>
            </div>
          </div>

          {/* Emergency Contact */}
          <div className="bg-white shadow sm:rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg font-medium leading-6 text-gray-900">
                {t('emergencyContact')}
              </h3>
              <div className="mt-6 grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
                <div className="sm:col-span-3">
                  <label htmlFor="emergencyContact" className="block text-sm font-medium text-gray-700">
                    {t('emergencyContactName')}
                  </label>
                  <input
                    type="text"
                    name="emergencyContact"
                    id="emergencyContact"
                    required
                    value={formData.emergencyContact}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  />
                </div>

                <div className="sm:col-span-3">
                  <label htmlFor="emergencyPhone" className="block text-sm font-medium text-gray-700">
                    {t('emergencyContactPhone')}
                  </label>
                  <input
                    type="tel"
                    name="emergencyPhone"
                    id="emergencyPhone"
                    required
                    value={formData.emergencyPhone}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Employment Information */}
          <div className="bg-white shadow sm:rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg font-medium leading-6 text-gray-900">
                {t('employmentInformation')}
              </h3>
              <div className="mt-6 grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
                <div className="sm:col-span-3">
                  <label htmlFor="occupation" className="block text-sm font-medium text-gray-700">
                    {t('occupation')}
                  </label>
                  <input
                    type="text"
                    name="occupation"
                    id="occupation"
                    required
                    value={formData.occupation}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  />
                </div>

                <div className="sm:col-span-3">
                  <label htmlFor="employer" className="block text-sm font-medium text-gray-700">
                    {t('employer')}
                  </label>
                  <input
                    type="text"
                    name="employer"
                    id="employer"
                    required
                    value={formData.employer}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  />
                </div>

                <div className="sm:col-span-3">
                  <label htmlFor="monthlyIncome" className="block text-sm font-medium text-gray-700">
                    {t('monthlyIncome')}
                  </label>
                  <div className="mt-1 relative rounded-md shadow-sm">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <span className="text-gray-500 sm:text-sm">₹</span>
                    </div>
                    <input
                      type="number"
                      name="monthlyIncome"
                      id="monthlyIncome"
                      required
                      value={formData.monthlyIncome}
                      onChange={handleInputChange}
                      className="mt-1 block w-full pl-7 rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Lease Information */}
          <div className="bg-white shadow sm:rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg font-medium leading-6 text-gray-900">
                {t('leaseInformation')}
              </h3>
              <div className="mt-6 grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
                <div className="sm:col-span-2">
                  <label htmlFor="moveInDate" className="block text-sm font-medium text-gray-700">
                    {t('moveInDate')}
                  </label>
                  <input
                    type="date"
                    name="moveInDate"
                    id="moveInDate"
                    required
                    value={formData.moveInDate}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label htmlFor="leaseLength" className="block text-sm font-medium text-gray-700">
                    {t('leaseLength')}
                  </label>
                  <select
                    name="leaseLength"
                    id="leaseLength"
                    required
                    value={formData.leaseLength}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  >
                    <option value="6">{t('months')}</option>
                    <option value="12">{t('months')}</option>
                    <option value="24">{t('months')}</option>
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <label htmlFor="roomNumber" className="block text-sm font-medium text-gray-700">
                    {t('roomNumber')}
                  </label>
                  <input
                    type="text"
                    name="roomNumber"
                    id="roomNumber"
                    required
                    value={formData.roomNumber}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  />
                </div>

                <div className="sm:col-span-3">
                  <label htmlFor="rentAmount" className="block text-sm font-medium text-gray-700">
                    {t('rentAmount')}
                  </label>
                  <div className="mt-1 relative rounded-md shadow-sm">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <span className="text-gray-500 sm:text-sm">₹</span>
                    </div>
                    <input
                      type="number"
                      name="rentAmount"
                      id="rentAmount"
                      required
                      value={formData.rentAmount}
                      onChange={handleInputChange}
                      className="mt-1 block w-full pl-7 rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                    />
                  </div>
                </div>

                <div className="sm:col-span-3">
                  <label htmlFor="depositAmount" className="block text-sm font-medium text-gray-700">
                    {t('depositAmount')}
                  </label>
                  <div className="mt-1 relative rounded-md shadow-sm">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <span className="text-gray-500 sm:text-sm">₹</span>
                    </div>
                    <input
                      type="number"
                      name="depositAmount"
                      id="depositAmount"
                      required
                      value={formData.depositAmount}
                      onChange={handleInputChange}
                      className="mt-1 block w-full pl-7 rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Document Upload */}
          <div className="bg-white shadow sm:rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg font-medium leading-6 text-gray-900">
                {t('documents')}
              </h3>
              <div className="mt-6">
                <div className="flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
                  <div className="space-y-1 text-center">
                    <ArrowUpTrayIcon className="mx-auto h-12 w-12 text-gray-400" />
                    <div className="flex text-sm text-gray-600">
                      <label
                        htmlFor="document-upload"
                        className="relative cursor-pointer rounded-md bg-white font-medium text-primary-600 focus-within:outline-none focus-within:ring-2 focus-within:ring-primary-500 focus-within:ring-offset-2 hover:text-primary-500"
                      >
                        <span>{t('uploadDocuments')}</span>
                        <input
                          id="document-upload"
                          type="file"
                          multiple
                          onChange={handleDocumentUpload}
                          className="sr-only"
                        />
                      </label>
                      <p className="pl-1">{t('dragAndDrop')}</p>
                    </div>
                    <p className="text-xs text-gray-500">{t('allowedFileTypes')}</p>
                  </div>
                </div>

                {/* Document List */}
                {documents.length > 0 && (
                  <ul className="mt-4 divide-y divide-gray-200">
                    {documents.map(doc => (
                      <li key={doc.id} className="py-3 flex justify-between items-center">
                        <div className="flex items-center">
                          <DocumentIcon className="h-5 w-5 text-gray-400" />
                          <span className="ml-2 text-sm text-gray-900">{doc.name}</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => removeDocument(doc.id)}
                          className="ml-4 text-sm font-medium text-red-600 hover:text-red-500"
                        >
                          {t('remove')}
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex justify-end space-x-4">
            <button
              type="button"
              onClick={() => navigate('/tenants')}
              className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
            >
              {t('cancel')}
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 disabled:bg-gray-400 disabled:cursor-not-allowed"
            >
              {loading ? t('saving') : t('saveTenant')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddTenant; 