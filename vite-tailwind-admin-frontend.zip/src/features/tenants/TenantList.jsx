import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { UserIcon, PlusIcon, PhoneIcon, HomeIcon, UserPlusIcon } from '@heroicons/react/24/outline';
import { useTranslation } from 'react-i18next';

const TenantList = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();

  const [tenants] = useState([
    { 
      id: 1, 
      name: 'John Doe', 
      phone: '+91 98765 43210', 
      room: '101',
      status: 'active',
      rentDue: '₹5000',
      joinDate: '2024-01-15'
    },
    // Add more sample tenants
  ]);

  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-semibold text-gray-900">
            {t('tenantListTitle')}
          </h1>
          <button
            type="button"
            onClick={() => navigate('/tenants/add')}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
          >
            <UserPlusIcon className="-ml-1 mr-2 h-5 w-5" />
            {t('addTenant')}
          </button>
        </div>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {tenants.map((tenant) => (
            <div
              key={tenant.id}
              className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow p-6"
            >
              <div className="flex items-center mb-4">
                <div className="bg-primary-100 rounded-full p-3">
                  <UserIcon className="h-6 w-6 text-primary-600" />
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-semibold text-gray-900">{tenant.name}</h3>
                  <span className={`px-2 py-1 rounded-full text-sm ${
                    tenant.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                  }`}>
                    {tenant.status}
                  </span>
                </div>
              </div>
              
              <div className="space-y-3">
                <div className="flex items-center text-gray-600">
                  <PhoneIcon className="h-5 w-5 mr-2" />
                  {tenant.phone}
                </div>
                <div className="flex items-center text-gray-600">
                  <HomeIcon className="h-5 w-5 mr-2" />
                  Room {tenant.room}
                </div>
                <div className="flex justify-between text-gray-600">
                  <span>Rent Due:</span>
                  <span className="font-medium text-red-600">{tenant.rentDue}</span>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span>Join Date:</span>
                  <span>{tenant.joinDate}</span>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-gray-200 flex space-x-3">
      <button 
        onClick={() => navigate(`/tenants/${tenant.id}`)}
        className="flex-1 text-primary-600 hover:text-primary-700 font-medium"
      >
        {t('viewDetails')}
      </button>
      <button 
        onClick={() => handleRemoveTenant(tenant.id)}
        className="flex-1 text-red-600 hover:text-red-700 font-medium"
      >
        {t('remove')}
      </button>
    </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TenantList; 