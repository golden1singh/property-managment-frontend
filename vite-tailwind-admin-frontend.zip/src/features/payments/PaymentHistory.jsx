const PaymentHistory = () => {
  return <div>Payment History</div>
}

export default PaymentHistory 