const PlotList = () => {
  return <div>Plot List</div>
}

export default PlotList 