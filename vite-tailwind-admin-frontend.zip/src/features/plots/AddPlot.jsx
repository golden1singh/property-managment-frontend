const AddPlot = () => {
  return <div>Add Plot</div>
}

export default AddPlot 