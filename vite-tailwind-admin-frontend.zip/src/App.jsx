import React from 'react'
import { useSelector } from 'react-redux'
import { ThemeProvider } from './contexts/ThemeContext'
import { LanguageProvider } from './contexts/LanguageContext'
import Header from './components/common/Header'
import AppRoutes from './routes'


function App() {
  const { isAuthenticated } = useSelector((state) => state.auth)

  return (
    <ThemeProvider>
      <LanguageProvider>
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
          {isAuthenticated && <Header />}
          <main className="pt-16 min-h-screen">
            <AppRoutes />
          </main>
        </div>
      </LanguageProvider>
    </ThemeProvider>
  )
}

export default App